package Class;
import Abstract.*;
public class Accordion extends Item{
    private final static String NAME = "гармошка ";
    public Accordion(){
        super(NAME);
    }
    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return super.toString();
    }

}
