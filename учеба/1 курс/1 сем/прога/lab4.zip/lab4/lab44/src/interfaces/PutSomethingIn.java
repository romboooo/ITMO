package interfaces;
import Abstract.Item;


public interface PutSomethingIn {
    void putIn(Item item);

}
