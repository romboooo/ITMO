package exceptions;

public class StoryIsEmpty extends Exception {

}
