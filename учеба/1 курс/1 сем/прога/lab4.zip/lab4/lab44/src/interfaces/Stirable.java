package interfaces;

public interface Stirable {
    void noStir();
}
