package interfaces;

public interface Soundable {
    void toSound();
}
