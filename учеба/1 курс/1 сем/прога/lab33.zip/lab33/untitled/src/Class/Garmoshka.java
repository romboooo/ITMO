package Class;
import Abstract.*;
public class Garmoshka extends Item{
    public Garmoshka(){
        super("гармошка. ");
    }
}
