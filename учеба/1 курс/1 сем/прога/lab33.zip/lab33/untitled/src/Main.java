import Class.*;
import Interface.PutSomethingIn;

public class Main {

    public static void main(String[] args) {
        MumiTroll mumitroll = new MumiTroll();
        Snusmumrik snusmumrik = new Snusmumrik();
        Sniff sniff = new Sniff();
        Garmoshka garmoshka = new Garmoshka();


        snusmumrik.FinishPlaying();
        System.out.printf(snusmumrik.getName());
        ((PutSomethingIn) snusmumrik).PutIn(garmoshka);

        mumitroll.Whistle(mumitroll.SecretSystem);

        System.out.print("Слышно было: ");
        System.out.printf(sniff.getName());
        sniff.StopSnore();
        sniff.NoStir();

    }
}