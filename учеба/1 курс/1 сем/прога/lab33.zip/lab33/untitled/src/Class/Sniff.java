package Class;
import Abstract.Hero;
public class Sniff extends Hero{
    public Sniff(){
        super("Снифф ");
    }
    public void StopSnore(){
        System.out.printf("перестал храпеть, ");
    }
    public void NoStir(){
        System.out.printf("но не шелохнулся.");
    }
}
