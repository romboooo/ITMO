package Class;
import Abstract.*;
import Interface.PutSomethingIn;

import java.util.ArrayList;
import java.util.List;

public class Snusmumrik extends Hero implements PutSomethingIn {

    public Snusmumrik(){
        super("Снусмумрик ");
    }

    public void FinishPlaying(){
        System.out.printf("Доиграв последнюю строчку своей весенней песенки, ");
    }

    public List<Item> packet = new ArrayList<>();  //создаем для снуса


    @Override
    public void PutIn(Item item) {
        packet.add(item);
        System.out.printf("Положил в карман " + item);

    }
}
