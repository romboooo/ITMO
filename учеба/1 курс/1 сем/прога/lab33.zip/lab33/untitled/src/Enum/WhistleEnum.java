package Enum;

public enum WhistleEnum {
    SIMPLE_WHISTLE,
    LONG_WHISTLE
}
