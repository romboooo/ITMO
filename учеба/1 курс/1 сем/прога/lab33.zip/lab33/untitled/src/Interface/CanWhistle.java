package Interface;
import Enum.WhistleEnum;
public interface CanWhistle {
    void Whistle(WhistleEnum...whistles);

}
