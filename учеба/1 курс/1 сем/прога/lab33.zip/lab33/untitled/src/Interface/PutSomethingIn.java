package Interface;
import Abstract.Item;


public interface PutSomethingIn {
    void PutIn(Item item);

}
