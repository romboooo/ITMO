package Class;
import Abstract.Hero;
import Enum.WhistleEnum;
import Interface.CanWhistle;
public class MumiTroll extends Hero implements CanWhistle {
    public MumiTroll(){
        super("Муми-тролль");
    }
   public final WhistleEnum[] SecretSystem = {     //массив "тайной системы" свистков
           WhistleEnum.SIMPLE_WHISTLE,
           WhistleEnum.SIMPLE_WHISTLE,
           WhistleEnum.SIMPLE_WHISTLE,
           WhistleEnum.LONG_WHISTLE
   };

    public void Whistle(WhistleEnum ...whistles){    //метод свиста по тайной системе
        String out = "Свистнул так: ";

        for (WhistleEnum whistle : whistles) {   // пробегаемcя по подаваемому в метод массиву свистков, выводим каждый
            if (whistle == WhistleEnum.SIMPLE_WHISTLE) { // каждый отдельный свист. Если свистки совпадают с
                out += "простой свист "; // тайной системой свисткой, тогда выполняется условие "есть дело".
            }
            else if (whistle == WhistleEnum.LONG_WHISTLE) {
                out += "долгий свист ";
            }
        }
        System.out.println(out);
        if (isWhistlesSecretSystem(whistles) == true){
            System.out.println("это значит: есть дело ");
        }
    }
    public boolean isWhistlesSecretSystem(WhistleEnum ...whistles) {   //
        return SecretSystem == whistles;
    }
}

